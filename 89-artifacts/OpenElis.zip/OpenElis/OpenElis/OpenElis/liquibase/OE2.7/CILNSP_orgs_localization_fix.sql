update clinlims.organization set name = 'GBOKLE-NAWA-SAN PÉDRO' where short_name = '2';
update clinlims.organization set name = 'N’ZI-IFOU' where short_name = '12';
update clinlims.organization set name = 'GBÈKÈ' where short_name = '17';
update clinlims.organization set name = 'M’BAHIAKRO' where short_name = '12.5';