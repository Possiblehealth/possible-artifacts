update clinlims.test_section set sort_order=10 where name = 'Immunology';
update clinlims.test_section set sort_order=20 where name = 'Hemto-Immunology';
update clinlims.test_section set sort_order=30 where name = 'Biochemistry';
update clinlims.test_section set sort_order=40 where name = 'Hematology';
update clinlims.test_section set sort_order=50 where name = 'Serology-Immunology';
