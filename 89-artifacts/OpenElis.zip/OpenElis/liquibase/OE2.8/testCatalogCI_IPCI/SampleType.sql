INSERT INTO type_of_sample( id, description, domain, lastupdated, local_abbrev, display_key, is_active )
	VALUES ( nextval( 'type_of_sample_seq' ) , 'Urines','H', now() , 'Urines', 'sample.type.Urines', 'Y');
INSERT INTO type_of_sample( id, description, domain, lastupdated, local_abbrev, display_key, is_active )
	VALUES ( nextval( 'type_of_sample_seq' ) , 'Serum','H', now() , 'Serum', 'sample.type.Serum', 'Y');
INSERT INTO type_of_sample( id, description, domain, lastupdated, local_abbrev, display_key, is_active )
	VALUES ( nextval( 'type_of_sample_seq' ) , 'Plasma','H', now() , 'Plasma', 'sample.type.Plasma', 'Y');
INSERT INTO type_of_sample( id, description, domain, lastupdated, local_abbrev, display_key, is_active )
	VALUES ( nextval( 'type_of_sample_seq' ) , 'Sang total','H', now() , 'Sang total', 'sample.type.SangTotal', 'Y');
