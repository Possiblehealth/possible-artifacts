INSERT INTO unit_of_measure( id, name , description, lastupdated) 
	VALUES ( nextval( 'unit_of_measure_seq' ) , 'Copies/ml (log)' , 'Copies/ml (log)' , now());
INSERT INTO unit_of_measure( id, name , description, lastupdated) 
	VALUES ( nextval( 'unit_of_measure_seq' ) , 'µl' , 'µl' , now());
