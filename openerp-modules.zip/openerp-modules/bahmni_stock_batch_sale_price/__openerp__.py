{
    "name": "Bahmni Batch Sale Price",
    "version": "1.0",
    "depends": ["base","stock","sale", "sale_stock","product_expiry"],
    "author": "ThoughtWorks Technologies Pvt. Ltd.",
    "category": "Sale",
	"summary": "Bahmni Batch Sale Price",
    "description": """
    """,
    'data': [
                'prod_lot_price_view.xml',
                'sale_order_line_extension.xml',
                'sale_batch_price_view.xml',
                'stock_view_prodlot.xml',
                'stock_move_view.xml',
                'sale_order_show_partner_reference.xml',
            ],
    'demo': [],
    'auto_install': False,
    'application': True,
    'installable': True,
#    'certificate': 'certificate',
}
