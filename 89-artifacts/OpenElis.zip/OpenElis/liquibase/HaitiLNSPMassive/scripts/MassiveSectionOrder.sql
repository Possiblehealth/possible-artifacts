update clinlims.test_section set sort_order=10 where name = 'Virologie';
update clinlims.test_section set sort_order=20 where name = 'Biologie Moleculaire';
update clinlims.test_section set sort_order=30 where name = 'Hematology';
update clinlims.test_section set sort_order=40 where name = 'Bacteria';
update clinlims.test_section set sort_order=50 where name = 'Parasitology';
update clinlims.test_section set sort_order=60 where name = 'Mycobacteriology';
