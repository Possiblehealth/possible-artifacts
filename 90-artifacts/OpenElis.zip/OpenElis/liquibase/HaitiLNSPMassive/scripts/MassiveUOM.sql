INSERT INTO unit_of_measure( id, name , description, lastupdated) 
	VALUES ( nextval( 'unit_of_measure_seq' ) , 'Copies/ml' , 'Copies/ml' , now());
INSERT INTO unit_of_measure( id, name , description, lastupdated) 
	VALUES ( nextval( 'unit_of_measure_seq' ) , 'μl' , 'μl' , now());
