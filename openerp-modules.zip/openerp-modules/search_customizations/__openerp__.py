{
    "name": "Search Customizations",
    "version": "1.0",
    "depends": ["base","stock", "account", "bahmni_sale_discount", "bahmni_print_bill", "bahmni_customer_payment"],
    "author": "ThoughtWorks Technologies Pvt. Ltd.",
    "category": "Report",
    "summary": "Reports",
    "description": """
    """,
    'data': ['account_report_view.xml', 'account_count_report_view.xml'],
    'demo': [],
    'qweb': ['static/src/xml/*.xml'],
    'auto_install': False,
    'application': True,
    'installable': True,
}
