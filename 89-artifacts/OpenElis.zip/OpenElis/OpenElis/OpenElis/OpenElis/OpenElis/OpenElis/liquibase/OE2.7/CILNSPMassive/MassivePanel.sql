INSERT INTO clinlims.panel( id, name, description, lastupdated, display_key, sort_order) VALUES
	(nextval( 'panel_seq' ) , 'CD4' , 'CD4' , now() ,'panel.name.CD4' ,10);
INSERT INTO clinlims.panel( id, name, description, lastupdated, display_key, sort_order) VALUES
	(nextval( 'panel_seq' ) , 'LCR' , 'LCR' , now() ,'panel.name.LCR' ,20);
INSERT INTO clinlims.panel( id, name, description, lastupdated, display_key, sort_order) VALUES
	(nextval( 'panel_seq' ) , 'NFS' , 'NFS' , now() ,'panel.name.NFS' ,30);
	