openerp-modules
===============

Custom openerp modules for Bhamni. All modules on deployment reside in the following location:

`usr/lib/python2.6/site-packages/openerp-7.0_20130301_002301-py2.6.egg/openerp/addons/`

The following modules are __obsolete__:

1. bahmni_logger
2. bahmni_dhis2_export
3. bahmni_lab_seed_setup

The following module is custom to __JSS__:

1. bahmni_seed_setup

Please read the following document on OpenERP setup:
https://github.com/Bhamni/bahmni-environment/blob/master/bahmni_box_setup_steps.md
