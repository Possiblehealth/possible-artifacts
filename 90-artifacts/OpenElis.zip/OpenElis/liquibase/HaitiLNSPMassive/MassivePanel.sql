INSERT INTO clinlims.panel( id, name, description, lastupdated, display_key, sort_order) VALUES
	(nextval( 'panel_seq' ) , 'CD4' , 'CD4' , now() ,'panel.name.CD4' ,10);
INSERT INTO clinlims.panel( id, name, description, lastupdated, display_key, sort_order) VALUES
	(nextval( 'panel_seq' ) , 'Antibiogramme Cholera' , 'Antibiogramme Cholera' , now() ,'panel.name.Antibiogramme' ,20);
INSERT INTO clinlims.panel( id, name, description, lastupdated, display_key, sort_order) VALUES
	(nextval( 'panel_seq' ) , 'Antibiogramme Shiguelle' , 'Antibiogramme Shiguelle' , now() ,'panel.name.Antibiogramme' ,30);
INSERT INTO clinlims.panel( id, name, description, lastupdated, display_key, sort_order) VALUES
	(nextval( 'panel_seq' ) , 'Antibiogramme Salmonelle' , 'Antibiogramme Salmonelle' , now() ,'panel.name.Antibiogramme' ,40);
INSERT INTO clinlims.panel( id, name, description, lastupdated, display_key, sort_order) VALUES
	(nextval( 'panel_seq' ) , 'Selles macro' , 'Selles macro' , now() ,'panel.name.Selles' ,50);
INSERT INTO clinlims.panel( id, name, description, lastupdated, display_key, sort_order) VALUES
	(nextval( 'panel_seq' ) , 'Selles micro' , 'Selles micro' , now() ,'panel.name.Selles' ,60);
INSERT INTO clinlims.panel( id, name, description, lastupdated, display_key, sort_order) VALUES
	(nextval( 'panel_seq' ) , 'Malaria' , 'Malaria' , now() ,'panel.name.Malaria' ,70);