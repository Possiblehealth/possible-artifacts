INSERT INTO clinlims.panel( id, name, description, lastupdated, display_key, sort_order) VALUES
	(nextval( 'panel_seq' ) , 'Serologie-Virologie' , 'Serologie-Virologie' , now() ,'panel.name.Serologie-Virologie' ,10);
INSERT INTO clinlims.panel( id, name, description, lastupdated, display_key, sort_order) VALUES
	(nextval( 'panel_seq' ) , 'Recherche de virus respiratoire par immunofuorescence directe' , 'Recherche de virus respiratoire par immunofuorescence directe' , now() ,'panel.name.Recherche' ,20);
INSERT INTO clinlims.panel( id, name, description, lastupdated, display_key, sort_order) VALUES
	(nextval( 'panel_seq' ) , 'CD4' , 'CD4' , now() ,'panel.name.CD4' ,30);
INSERT INTO clinlims.panel( id, name, description, lastupdated, display_key, sort_order) VALUES
	(nextval( 'panel_seq' ) , 'Hemogramme-Auto' , 'Hemogramme-Auto' , now() ,'panel.name.Hemogramme-Auto' ,40);
INSERT INTO clinlims.panel( id, name, description, lastupdated, display_key, sort_order) VALUES
	(nextval( 'panel_seq' ) , 'Antibiogramme' , 'Antibiogramme' , now() ,'panel.name.Antibiogramme' ,50);
INSERT INTO clinlims.panel( id, name, description, lastupdated, display_key, sort_order) VALUES
	(nextval( 'panel_seq' ) , 'Miscellaneous  Bacteriologie' , 'Miscellaneous  Bacteriologie' , now() ,'panel.name.Miscellaneous' ,60);
INSERT INTO clinlims.panel( id, name, description, lastupdated, display_key, sort_order) VALUES
	(nextval( 'panel_seq' ) , 'Selles Routine' , 'Selles Routine' , now() ,'panel.name.Selles' ,70);
INSERT INTO clinlims.panel( id, name, description, lastupdated, display_key, sort_order) VALUES
	(nextval( 'panel_seq' ) , 'Malaria' , 'Malaria' , now() ,'panel.name.Malaria' ,80);
