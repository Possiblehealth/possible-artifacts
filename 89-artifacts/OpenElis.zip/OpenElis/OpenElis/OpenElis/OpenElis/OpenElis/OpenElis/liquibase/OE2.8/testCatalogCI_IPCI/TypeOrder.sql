update clinlims.type_of_sample set sort_order=10 where description ILIKE 'Serum';
update clinlims.type_of_sample set sort_order=20 where description ILIKE 'Plasma';
update clinlims.type_of_sample set sort_order=30 where description ILIKE 'Urines';
update clinlims.type_of_sample set sort_order=40 where description ILIKE 'Urine';
update clinlims.type_of_sample set sort_order=50 where description ILIKE 'Sang total';
