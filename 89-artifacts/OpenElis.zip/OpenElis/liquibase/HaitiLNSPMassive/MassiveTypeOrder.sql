update clinlims.type_of_sample set sort_order=10 where description ILIKE 'Sang';
update clinlims.type_of_sample set sort_order=40 where description ILIKE 'Serum';
update clinlims.type_of_sample set sort_order=50 where description ILIKE 'Plasma';
update clinlims.type_of_sample set sort_order=110 where description ILIKE 'DBS';
update clinlims.type_of_sample set sort_order=120 where description ILIKE 'Ecouvillon Nasal';
update clinlims.type_of_sample set sort_order=130 where description ILIKE 'Ecouvillon Naso-Pharynge';
update clinlims.type_of_sample set sort_order=150 where description ILIKE 'Aspiration Naso-Pharyngee';
update clinlims.type_of_sample set sort_order=70 where description ILIKE 'Selles 1';
update clinlims.type_of_sample set sort_order=80 where description ILIKE 'Selles 2';
update clinlims.type_of_sample set sort_order=60 where description ILIKE 'Selles';
update clinlims.type_of_sample set sort_order=20 where description ILIKE 'Sang Total';
update clinlims.type_of_sample set sort_order=100 where description ILIKE 'LCR';
update clinlims.type_of_sample set sort_order=140 where description ILIKE 'Ecouvillon Pharynge';
update clinlims.type_of_sample set sort_order=30 where description ILIKE 'Sang capillaire';
update clinlims.type_of_sample set sort_order=90 where description ILIKE 'Expectoration';


