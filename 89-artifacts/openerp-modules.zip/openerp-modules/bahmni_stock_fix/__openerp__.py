{
    "name": "Bahmni stock fix",
    "version": "1.0",
    "depends": ["base", "bahmni_internal_stock_move"],
    "author": "ThoughtWorks Technologies Pvt. Ltd.",
    "category": "",
    "summary": "Code to create internal moves for old stock batches.",
    "description": """
    """,
    'data': ['old_prodlot_move_view.xml','stock_inventory_fix.xml'],
    'demo': [],
    'auto_install': False,
    'application': True,
    'installable': True,
}
