INSERT INTO clinlims.panel( id, name, description, lastupdated, display_key, sort_order) VALUES
	(nextval( 'panel_seq' ) , 'Bilan Biochimique' , 'Bilan Biochimique' , now() ,'panel.name.Bilan' ,10);
INSERT INTO clinlims.panel( id, name, description, lastupdated, display_key, sort_order) VALUES
	(nextval( 'panel_seq' ) , 'NFS' , 'NFS' , now() ,'panel.name.NFS' ,20);
INSERT INTO clinlims.panel( id, name, description, lastupdated, display_key, sort_order) VALUES
	(nextval( 'panel_seq' ) , 'Typage lymphocytaire' , 'Typage lymphocytaire' , now() ,'panel.name.Typage' ,30);
INSERT INTO clinlims.panel( id, name, description, lastupdated, display_key, sort_order) VALUES
	(nextval( 'panel_seq' ) , 'Serologie VIH' , 'Serologie VIH' , now() ,'panel.name.Serologie' ,40);

	