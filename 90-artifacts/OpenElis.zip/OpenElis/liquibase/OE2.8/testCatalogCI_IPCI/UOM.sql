INSERT INTO unit_of_measure( id, name , description, lastupdated) 
	VALUES ( nextval( 'unit_of_measure_seq' ) , 'million/mm3' , 'million/mm3' , now());
