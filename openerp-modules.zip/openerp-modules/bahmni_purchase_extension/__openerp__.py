{
    "name": "Bhamni Purchase flow Enhancements",
    "version": "1.0",
    "depends": ["base","purchase", "bahmni_stock_batch_sale_price", "product"],
    "author": "ThoughtWorks tecnologies Pvt. Ltd.",
    "category": "Purchase",
	"summary": "Purchase flow Enhancements",
    "description": """
    """,
    'data': ['purchase_order_view_enhancements.xml', 'order_report.xml', 'product_supplier_view_enhancements.xml'],
    'demo': [],
    'css' : [
        "static/src/css/purchase_order_view_enhancements.css",
    ],
    'auto_install': False,
    'application': True,
    'installable': True,
#    'certificate': 'certificate',
}
