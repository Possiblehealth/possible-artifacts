#! /usr/bin/python

import os

__author__="paulsc"
__date__ ="$May 29, 2012 1:17:54 PM$"

if __name__ == "__main__":
    print("dictionary.py")
    os.system( "python dictionary.py" )
    print("\npanels.py")
    os.system( "python panels.py" )
    print("\nresultLimits.py")
    os.system( "python resultLimits.py" )
    print("\nsampleType.py")
    os.system( "python sampleType.py" )
    print("\nsampleTypePanel.py")
    os.system( "python sampleTypePanel.py" )
    print("\nsampleTypeTest.py")
    os.system( "python sampleTypeTest.py" )
    print("\nsortSections .py")
    os.system( "python sortSections.py" )
    print("\ntestEntry.py")
    os.system( "python testEntry.py" )
    print("\ntestPanel.py")
    os.system( "python testPanel.py" )
    print("\ntestResult.py")
    os.system( "python testResult.py" )
    print("\nuom.py")
    os.system( "python uom.py" )
    print("\ntestCodes.py")
    os.system( "python testCodes.py" )
    print("\norderType.py")
    os.system( "python orderType.py" )
