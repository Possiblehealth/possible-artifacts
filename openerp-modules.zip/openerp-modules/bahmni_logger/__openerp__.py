{
    "name": "Bahmni logger",
    "version": "6.0",
    "depends": [],
    "author": "ThoughtWorks Technologies Pvt. Ltd.",
    "category": "Setup",
    "summary": "Error email log handler",
    "description": """
    """,
    'data': [],
    'demo': [],
    'auto_install': True,
    'application': True,
    'installable': True,
#    'certificate': 'certificate',
}
