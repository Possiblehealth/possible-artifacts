{
    "name": "Bhamni Pharmacy Product",
    "version": "6.0",
    "depends": ["base","product", "stock","bahmni_atom_feed", "purchase"],
    "author": "ThoughtWorks tecnologies Pvt. Ltd.",
    "category": "Product",
	"summary": "Pharmacy Product",
    "description": """
    """,
    'data': [
        'security/ir.model.access.csv',
        'product_pharmacy_view.xml'
    ],
    'demo': [],
    'auto_install': False,
    'application': True,
    'installable': True,
#    'certificate': 'certificate',
}
